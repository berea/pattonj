
//----------------------------------------------
// Used for Berea College Hobsons Connect to populate various fields	
// Created by Jacob Patton (C) 2017,2018				
//----------------------------------------------

setListener();

// variables
var currentLocation; 	// What's my URL? 
var viewDropDownValue; 	// What's the view? 
var visitDate;			// What date mm/dd/yyyy am I visiting? (CV Registration View)
var feeDate;			// What date mm/dd/yyyy was the deposit paid? (Dec of Intent View)
var fieldInterval;		// Loop for watching field
var highSchoolName;		// What is the current High School Name? (HS Transcript/Counselor Evaluation Form View)

//on load, set main listener for dropdown view. 
function setListener() {
	currentLocation = window.location.pathname;
	if(currentLocation === "/admin/Contacts/Search" || currentLocation === "/admin/Contacts/View" || currentLocation === "/admin/Contacts/Edit"){
		//set view listener
		document.getElementById("contactViews").addEventListener("change", viewUpdate);
		//Trigger once edit is clicked 
		if(document.getElementById("editMode") !== null){
			document.getElementById("editMode").addEventListener("click",viewUpdate);
		} else if(document.getElementById("newMode") !== null){
			document.getElementById("newMode").addEventListener("click",viewUpdate);
		}
		//Now run view change update
		viewUpdate();
	}
}

//view change function
function viewUpdate(){
	//Remove the BereaButton so we can recreate it if needed. 
	if (document.getElementById('bereaButton') !== null){
		var oldButton = document.getElementById("bereaButton");
		oldButton.remove();
	}
	//Make sure we clear interval for the field if we are watching for a change. 
	clearInterval(fieldInterval);
	
	//Get the title of the selected dropdown value and remove * if needed. 
	viewDropDownValue = document.getElementById("contactViews").options[document.getElementById("contactViews").selectedIndex].title;
	if( viewDropDownValue.slice(-1)==="*"){
		viewDropDownValue = viewDropDownValue.slice(0, -1);
	} 
	
	//Rewrote as a switch instead of if/else since I added actions. 
	switch (viewDropDownValue){
		case "Campus Visit Itinerary":
			createCVItineraryButton();
			break;
		case "Campus Visit Reservation":
			fieldWatch("date602Date",createCVReservationDateListener);
			break;
		case "HS Transcript / Counselor Evaluation Form":
			fieldWatch("hsname",checkHSTranscriptNameChange);
			break;
		case "Evaluations and Endorsements":
			fieldWatch("text219",createEEListeners);
			break;	
		case "Dec of Intent / Ent Fee / Non-Enrolling Form":
			fieldWatch ("date2951Date",setFeeDateListener);
			break;
	}
	
	
}

//look for the field I need to edit to exist. 
function fieldWatch(myField,func){
	//set loop looking for the field to exist and be editable. 
	fieldInterval = setInterval(function () {
		if(document.getElementById(myField) !== null){
			if (document.getElementById(myField).disabled === false) {  
				clearInterval(fieldInterval);
				func();
			}
		}
    }, 200);
}


//-----------//Multi-use functions//-----------//

//Clear if they select OK from the confirm box on click. 
function clearDateChange(myDateField){
	//myDateField.blur();
	if(myDateField.value === ""){
		alert("Please use date picker to set the date.");
	}else{
		if (confirm("Please use date picker to set the date. \n \nWould you like to clear the date?\n \n")){
			myDateField.value = "";
		}else{
			return;
		}
	}
	
}


//--------------
//Campus Visit Functions
//--------------

//-----------//CVItinerary Functions//-----------//

//Creates the main button.
function createCVItineraryButton() {
	/*Dropdown menu from here https://www.w3schools.com/howto/howto_js_dropdown.asp*/
	//Create our HTML to inject.
	var bereaButton = document.createElement("div");
	bereaButton.style = "float:right";
	bereaButton.id = "bereaButton";
	bereaButton.innerHTML = "<div class='BereaDropdown'>"+
		"<input ID='Berea_Menu_Button' value='Berea Visits' class='BereaBlue bigbutton new' type='button' onclick='return false;'>"+
	  "<div id='BereaMenu' class='BereaDropdown-content'>"+
		"<a href='#' ID='AM_No_Lunch' onclick='return false;'>AM Session</a>"+
		"<a href='#' ID='AM_With_Lunch' onclick='return false;'>AM Session (Lunch)</a>"+
		"<a href='#' ID='PM_Session' onclick='return false;'>PM Session</a>"+
		"<a href='#' ID='Midday_Session' onclick='return false;'>Midday Session</a>"+
		"<a href='#' ID='Clear_Session'onclick='return false;' >Clear Sessions</a>"+
	  "</div></div>";
	var buttonRow = document.getElementsByClassName('triggerBtnsTop');
	buttonRow[0].appendChild(bereaButton);
	//Set even listeners "click" for the buttons above.
	document.getElementById("Berea_Menu_Button").addEventListener("click",showCVItineraryMenu);
	document.getElementById("AM_No_Lunch").addEventListener("click",function(){creatCVItinerary(1);});
	document.getElementById("AM_With_Lunch").addEventListener("click",function(){creatCVItinerary(2);});
	document.getElementById("PM_Session").addEventListener("click",function(){creatCVItinerary(3);});
	document.getElementById("Midday_Session").addEventListener("click",function(){creatCVItinerary(4);});
	document.getElementById("Clear_Session").addEventListener("click",clearCVItinerary);
	

	/*Just as a side note incase I ever need to insert a script code 
	https://www.danielcrabtree.com/blog/25/gotchas-with-dynamically-adding-script-tags-to-html*/
	//}
}

//Shows the dropdown menu
function showCVItineraryMenu() {    
		
		//The warning box area that connect uses. 
		var warningBox = document.getElementById("messagePanel");
		//Checking our contact views. For some reason they have two different values depending on the page your on. 
		 if(document.getElementById("contactViews").value === "1651" || document.getElementById("contactViews").value === "1647"){
			if(document.getElementById("text598").disabled === false){
				document.getElementById('BereaMenu').classList.toggle('show');
				
				window.onclick = function(event) {
					//Close the dropdown menu if the user clicks outside of it
				  if (!event.target.matches('.BereaBlue')) {

					var dropdowns = document.getElementsByClassName("BereaDropdown-content");
					var i;
					for (i = 0; i < dropdowns.length; i++) {
					  var openDropdown = dropdowns[i];
					  if (openDropdown.classList.contains('show')) {
						openDropdown.classList.remove('show');
					  }
					}
				  } else{
					  return ;
				  }
				};
				
			}
			else{
				//Show unable to update field warning. 
				var fieldWarning = document.createElement("div");
				fieldWarning.className = "simplemessage-warning";
				fieldWarning.innerHTML = "Unable to edit itinerary fields.<br><br>";
				warningBox.innerHTML ="";
				warningBox.appendChild(fieldWarning);
				return;
			}
			
		 } 
}

//Creates the itineray and fills in the fields
//I could reduce the lines of code to fill in the activity, location and detail, and then separate times
//but I kept them apart so that in the future if they need to be different they can
function creatCVItinerary(x){
	//Look to see if they need an interview. 	
	var scheduleInterview = document.getElementById("text3791").value;
	
	if(x === 2 || x=== 1){
		
		//Visit Type
		document.getElementById('text598').value ="Weekday Morning Session";
		//Arrival Time
		document.getElementById('text3381').value ="8:45 a.m.";
		//activity 1 (Activity, time, location, detail)
		document.getElementById('text3321').value ="Arrive on Campus";
		document.getElementById('text3341').value ="8:45 a.m.";
		document.getElementById('text4581').value ="Haaga House";
		document.getElementById('text4541').value ="- Lobby";
		//activity 2
		document.getElementById('text4681').value ="Introduction to Berea";
		document.getElementById('text4627').value ="9:00 a.m.";
		document.getElementById('text4589').value ="Haaga House";
		document.getElementById('text4543').value ="- Presentation Room";
		//activity 3
		document.getElementById('text4683').value ="Information Session";
		document.getElementById('text4629').value ="9:10 a.m.";
		document.getElementById('text4591').value ="Haaga House";
		document.getElementById('text4545').value ="- Presentation Room";
		//activity 4
		//Look to see if scheduled interview is yes, otherwise we assume personal conversation
		if (scheduleInterview === "y"){
			document.getElementById('text4685').value ="Personal Interview";
		}
		else{
			document.getElementById('text4685').value ="Personal Conversation w/ Counselor";
		}
		document.getElementById('text4631').value ="9:45 a.m.";
		document.getElementById('text4593').value ="Haaga House";
		document.getElementById('text4547').value ="With Admissions Counselor";
		//activity 5
		document.getElementById('text4687').value ="Student Panel";
		document.getElementById('text4633').value ="10:05 a.m.";
		document.getElementById('text4595').value ="Haaga House";
		document.getElementById('text4549').value ="- Lobby";
		//activity 6
		document.getElementById('text4689').value ="Tour of Campus";
		document.getElementById('text4635').value ="10:30 a.m.";
		document.getElementById('text4597').value ="";
		document.getElementById('text4551').value ="With Student Ambassador";
		
		//For 1* visit, no lunch
		if(x === 1){
			//activity 7
			document.getElementById('text4691').value ="Depart from Campus";
			document.getElementById('text4637').value ="12:00 a.m.";
			document.getElementById('text4599').value ="";
			document.getElementById('text4553').value ="";
			//clear activity 8
			document.getElementById('text4693').value ="";
			document.getElementById('text4639').value ="";
			document.getElementById('text4601').value ="";
			document.getElementById('text4555').value ="";
		//For 4* visit with lunch
		} else if (x === 2){
			//Activity 7
			document.getElementById('text4691').value ="Lunch";
			document.getElementById('text4637').value ="12:00 a.m.";
			document.getElementById('text4599').value ="Dining Services";
			document.getElementById('text4553').value ="With Student Ambassador";
			//activity 8
			document.getElementById('text4693').value ="Depart from Campus";
			document.getElementById('text4639').value ="1:00 p.m.";
			document.getElementById('text4601').value ="";
			document.getElementById('text4555').value ="";
		}
	return false;
	} else if( x === 3) {
		//Visit Type
		document.getElementById('text598').value ="Weekday Afternoon Session";
		//Arrival Time
		document.getElementById('text3381').value ="1:15 p.m.";
		//activity 1 (Activity, time, location, detail)
		document.getElementById('text3321').value ="Arrive on Campus";
		document.getElementById('text3341').value ="1:15 p.m.";
		document.getElementById('text4581').value ="Haaga House";
		document.getElementById('text4541').value ="- Lobby";
		//activity 2
		document.getElementById('text4681').value ="Introduction to Berea";
		document.getElementById('text4627').value ="1:30 p.m.";
		document.getElementById('text4589').value ="Haaga House";
		document.getElementById('text4543').value ="- Presentation Room";
		//activity 3
		document.getElementById('text4683').value ="Information Session";
		document.getElementById('text4629').value ="1:40 p.m.";
		document.getElementById('text4591').value ="Haaga House";
		document.getElementById('text4545').value ="- Presentation Room";
		//activity 4
		//Look to see if scheduled interview is yes, otherwise we assume personal conversation
		if (scheduleInterview === "y"){
			document.getElementById('text4685').value ="Personal Interview";
		}
		else{
			document.getElementById('text4685').value ="Personal Conversation w/ Counselor";
		}
		document.getElementById('text4631').value ="2:15 p.m.";
		document.getElementById('text4593').value ="Haaga House";
		document.getElementById('text4547').value ="with Admissions Counselor";
		//activity 5
		document.getElementById('text4687').value ="Student Panel";
		document.getElementById('text4633').value ="2:35 p.m.";
		document.getElementById('text4595').value ="Haaga House";
		document.getElementById('text4549').value ="- Lobby";
		//activity 6
		document.getElementById('text4689').value ="Tour of Campus";
		document.getElementById('text4635').value ="3:00 p.m.";
		document.getElementById('text4597').value ="";
		document.getElementById('text4551').value ="With Student Ambassador";
		//activity 7
		document.getElementById('text4691').value ="Depart from Campus";
		document.getElementById('text4637').value ="4:30 p.m.";
		document.getElementById('text4599').value ="";
		document.getElementById('text4553').value ="";
		//clear activity 8
		document.getElementById('text4693').value ="";
		document.getElementById('text4639').value ="";
		document.getElementById('text4601').value ="";
		document.getElementById('text4555').value ="";
		
	} else if( x === 4) {
		
		//Visit Type
		document.getElementById('text598').value ="Weekday Midday Session";
		//Arrival Time
		document.getElementById('text3381').value ="10:15 a.m.";
		//activity 1 (Activity, time, location, detail)
		document.getElementById('text3321').value ="Arrive on Campus";
		document.getElementById('text3341').value ="10:15 a.m.";
		document.getElementById('text4581').value ="Haaga House";
		document.getElementById('text4541').value ="- Lobby";
		//activity 2
		document.getElementById('text4681').value ="Introduction to Berea";
		document.getElementById('text4627').value ="10:30 a.m.";
		document.getElementById('text4589').value ="Haaga House";
		document.getElementById('text4543').value ="- Presentation Room";
		//activity 3
		document.getElementById('text4683').value ="Information Session";
		document.getElementById('text4629').value ="10:40 a.m.";
		document.getElementById('text4591').value ="Haaga House";
		document.getElementById('text4545').value ="- Presentation Room";
		//activity 4
		//Look to see if scheduled interview is yes, otherwise we assume personal conversation
		if (scheduleInterview === "y"){
			document.getElementById('text4685').value ="Personal Interview";
		}
		else{
			document.getElementById('text4685').value ="Personal Conversation w/ Counselor";
		}
		document.getElementById('text4631').value ="11:15 a.m.";
		document.getElementById('text4547').value ="With Admissions Counselor";
		document.getElementById('text4593').value ="Haaga House";
		//activity 5
		document.getElementById('text4687').value ="Student Panel";
		document.getElementById('text4633').value ="11:35 a.m.";
		document.getElementById('text4595').value ="Haaga House";
		document.getElementById('text4549').value ="- Lobby";
		//activity 6
		document.getElementById('text4689').value ="Lunch";
		document.getElementById('text4635').value ="12:05 p.m.";
		document.getElementById('text4597').value ="Dining Services";
		document.getElementById('text4551').value ="With Student Ambassador";
		//activity 7
		document.getElementById('text4691').value ="Tour of Campus";
		document.getElementById('text4637').value ="12:45 p.m.";
		document.getElementById('text4599').value ="";
		document.getElementById('text4553').value ="";
		//activity 8
		document.getElementById('text4693').value ="Depart from Campus";
		document.getElementById('text4639').value ="1:45 p.m.";
		document.getElementById('text4601').value ="";
		document.getElementById('text4555').value ="";
	}
		//Clear activity 9 and 10 since we don't use it. 
		//activity 9
		document.getElementById('text4695').value ="";
		document.getElementById('text4641').value ="";
		document.getElementById('text4603').value ="";
		document.getElementById('text4557').value ="";
		//activity 10
		document.getElementById('text4697').value ="";
		document.getElementById('text4643').value ="";
		document.getElementById('text4605').value ="";
		document.getElementById('text4559').value ="";
}

//Clears all itinerary fields
function clearCVItinerary(){
	//Visit Type
		document.getElementById('text598').value ="";
		//Arrival Time
		document.getElementById('text3381').value ="";
		//activity 1 (Activity, time, location, detail)
		document.getElementById('text3321').value ="";
		document.getElementById('text3341').value ="";
		document.getElementById('text4581').value ="";
		document.getElementById('text4541').value ="";
		//activity 2
		document.getElementById('text4681').value ="";
		document.getElementById('text4627').value ="";
		document.getElementById('text4589').value ="";
		document.getElementById('text4543').value ="";
		//activity 3
		document.getElementById('text4683').value ="";
		document.getElementById('text4629').value ="";
		document.getElementById('text4591').value ="";
		document.getElementById('text4545').value ="";
		//activity 4
		document.getElementById('text4685').value ="";
		document.getElementById('text4631').value ="";
		document.getElementById('text4593').value ="";
		document.getElementById('text4547').value ="";
		//activity 5
		document.getElementById('text4687').value ="";
		document.getElementById('text4633').value ="";
		document.getElementById('text4595').value ="";
		document.getElementById('text4549').value ="";
		//activity 6
		document.getElementById('text4689').value ="";
		document.getElementById('text4635').value ="";
		document.getElementById('text4597').value ="";
		document.getElementById('text4551').value ="";
		//activity 7
		document.getElementById('text4691').value ="";
		document.getElementById('text4637').value ="";
		document.getElementById('text4599').value ="";
		document.getElementById('text4553').value ="";
		//clear activity 8
		document.getElementById('text4693').value ="";
		document.getElementById('text4639').value ="";
		document.getElementById('text4601').value ="";
		document.getElementById('text4555').value ="";
		//activity 9
		document.getElementById('text4695').value ="";
		document.getElementById('text4641').value ="";
		document.getElementById('text4603').value ="";
		document.getElementById('text4557').value ="";
		//activity 10
		document.getElementById('text4697').value ="";
		document.getElementById('text4643').value ="";
		document.getElementById('text4605').value ="";
		document.getElementById('text4559').value ="";
}


//-----------//CVReservation Functions//-----------//
	
function createCVReservationDateListener(){
	visitDate = document.getElementById("date602Date").value;
	//Blank ability set through confirm box yes/no.  
	document.getElementById("date602Date").addEventListener("click",function(){clearDateChange(document.getElementById("date602Date"));});
	document.getElementById("date602Date").addEventListener("keydown",function(e){e.preventDefault(); alert("Please use date picker to set the date.");});
	document.getElementById("date602Date").addEventListener("focusout",checkCVResDateChange);
	document.getElementById("text598").addEventListener("change",setArrivalTime);
}

//pauses long enough wait for the date to be populated and then compare, and if needed set day. 
function checkCVResDateChange(){
	
	setTimeout( function(){
	if(document.getElementById("date602Date").value !==""){	
		var newVal = document.getElementById("date602Date").value;
		//set loop looking for the field to exist and be editable.
		if (visitDate === newVal) {  
			//console.log("no change");
		 } else{
			visitDate = newVal;
			//Grab date and update the field.
			switch(new Date(document.getElementById("date602Date").value).getDay()){
				case 0:
					document.getElementById("text4421").value = "Sunday";
					break;
				case 1:
					document.getElementById("text4421").value = "Monday";
					break;
				case 2:
					document.getElementById("text4421").value = "Tuesday";
					break;
				case 3:
					document.getElementById("text4421").value = "Wednesday";
					break;
				case 4:
					document.getElementById("text4421").value = "Thursday";
					break;
				case 5:
					document.getElementById("text4421").value = "Friday";
					break;
				case 6:
					document.getElementById("text4421").value = "Saturday";
					break;
				default:
					document.getElementById("text4421").value = "";
			}	
		}
	}else{
		document.getElementById("text4421").value = "";
		visitDate="";
	} 
	},150);
}

//used to set the arrival time when session type is selected
function setArrivalTime(){
	switch (document.getElementById("text598").value){
		case "Weekday Morning Session":
			document.getElementById("text3381").value = "8:45 a.m.";
			break;
		case "Weekday Midday Session":
			document.getElementById("text3381").value = "10:15 a.m.";
			break;
		case "Weekday Afternoon Session":
			document.getElementById("text3381").value = "1:15 p.m.";
			break;
		case "": // If they return to "select one", which is really blank. 
			document.getElementById("text3381").value = "";
			break;
		default:
			//do nothing
			break;
	}
	
}


//--------------
//Processing Function
//--------------

//-----------//Evaluation and Endorsements//-----------//

//create the listeners for the text boxes
function createEEListeners(){
	//set listener for name 1 pass that it's box 1
	document.getElementById("text219").addEventListener("input", function(){setEEDate("text219","date6485Date");});
	document.getElementById("text223").addEventListener("input", function(){setEEDate("text223","date6487Date");});
}

//if updated, check to see if date is empty, and if not, insert todays date.
function setEEDate(EEName,EEDate){
	var currentTime; 
	if(document.getElementById(EEName).value!==""){
		if(document.getElementById(EEDate).value === ""){
			currentTime = new Date();
			document.getElementById(EEDate).value = (currentTime.getMonth() + 1) +"/"+currentTime.getDate()+"/"+currentTime.getFullYear();
		}
	}
}

//-----------//High School Transcripts//-----------//
function checkHSTranscriptNameChange(){
	highSchoolName = document.getElementById("hsname").value;
	
	//set loop looking for the field to exist and be editable.
	//resused fieldInterval as it has been cleared when we are able to edit. 
	fieldInterval = setInterval(function () {
	if(document.getElementById("hsname").value !==""){	
		var newVal = document.getElementById("hsname").value;
		//compare original hs name value to current value
		if (highSchoolName === newVal) {  
		 } else{
			//set the name to compare to. 
			highSchoolName = document.getElementById("hsname").value;
			//copy the high school name. 
			document.getElementById("text1501").value = highSchoolName;
		}	
	} 
	},100);
}

//-----------//Fee Date and Fee Amount//-----------//


function setFeeDateListener(){
	feeDate = document.getElementById("date2951Date").value;
	document.getElementById("date2951Date").addEventListener("click",function(){clearDateChange(document.getElementById("date2951Date"));});
	document.getElementById("date2951Date").addEventListener("keydown",function(e){e.preventDefault(); alert("Please use your date picker to set the date.");});
	document.getElementById("date2951Date").addEventListener("focusout",checkFeeDateChange);
}

//Set fee amount, or clear the amount if the date is removed. 
function checkFeeDateChange(){
	
	setTimeout( function(){
	if(document.getElementById("date2951Date").value !==""){	
		var newVal = document.getElementById("date2951Date").value;
		//set loop looking for the field to exist and be editable.
		if (feeDate === newVal) {  
			console.log("no change");
		 } else{
			feeDate = newVal;
			document.getElementById("numeric2821").value = "50";
		}	
	}else{
		document.getElementById("numeric2821").value = "";	
		feeDate = "";
	} 
	},100);
}








//----------------------------------------------
// Used for Berea College Hobsons Connect to populate itinerary fields.		
// Created by Jacob Patton (C) 2017				
//----------------------------------------------


createButton();

//Creates the main button.
function createButton() {

//Look to see what our URL is.
var currentLocation = window.location.pathname;

//if our URL is one of the three that we can update the fields, create the button and menu. 
if(currentLocation === "/admin/Contacts/Search" || currentLocation === "/admin/Contacts/View" || currentLocation === "/admin/Contacts/Edit"){

	//Checks to see if the button already exists. If it does, remove it before recreating it. 
	if (document.getElementById('cvButton') !== null){
		var oldButton = document.getElementById("cvButton");
		oldButton.remove();
	}
	
	/*Dropdown menu from here https://www.w3schools.com/howto/howto_js_dropdown.asp*/
	//Create our HTML to inject.
	var cvButton = document.createElement("div");
	cvButton.style = "float:right";
	cvButton.id = "cvButton";
	cvButton.innerHTML = "<div class='BereaDropdown'>"+
		"<input ID='Berea_Menu_Button' value='Berea Visits' class='BereaBlue bigbutton new' type='button' onclick='return false;'>"+
	  "<div id='BereaMenu' class='BereaDropdown-content'>"+
		"<a href='#' ID='AM_No_Lunch' onclick='return false;'>AM Session</a>"+
		"<a href='#' ID='AM_With_Lunch' onclick='return false;'>AM Session (Lunch)</a>"+
		"<a href='#' ID='PM_Session' onclick='return false;'>PM Session</a>"+
		"<a href='#' ID='Midday_Session' onclick='return false;'>Midday Session</a>"+
		"<a href='#' ID='Clear_Session'onclick='return false;' >Clear Sessions</a>"+
	  "</div></div>";
	var buttonRow = document.getElementsByClassName('triggerBtnsTop');
	buttonRow[0].appendChild(cvButton);
	//Set even listeners "click" for the buttons above.
	document.getElementById("Berea_Menu_Button").addEventListener("click",showBereaMenu);
	document.getElementById("AM_No_Lunch").addEventListener("click",function(){creatBereaItinerary(1);});
	document.getElementById("AM_With_Lunch").addEventListener("click",function(){creatBereaItinerary(2);});
	document.getElementById("PM_Session").addEventListener("click",function(){creatBereaItinerary(3);});
	document.getElementById("Midday_Session").addEventListener("click",function(){creatBereaItinerary(4);});
	document.getElementById("Clear_Session").addEventListener("click",clearItinerary);
	
	

	/*Just as a side note incase I ever need to insert a script code 
	https://www.danielcrabtree.com/blog/25/gotchas-with-dynamically-adding-script-tags-to-html*/
	}
}

//Shows the dropdown menu
function showBereaMenu() {    
		
		//The warning box area that connect uses. 
		var warningBox = document.getElementById("messagePanel");
		//Checking our contact views. For some reason they have two different values depending on the page your on. 
		 if(document.getElementById("contactViews").value === "1651" || document.getElementById("contactViews").value === "1647"){
			if(document.getElementById("text598").disabled === false){
				document.getElementById('BereaMenu').classList.toggle('show');	
			}
			else{
				//Show unable to update field warning. 
				var fieldWarning = document.createElement("div");
				fieldWarning.className = "simplemessage-warning";
				fieldWarning.innerHTML = "Unable to edit itinerary fields.<br><br>";
				warningBox.innerHTML ="";
				warningBox.appendChild(fieldWarning);
				return;
			}
			
		 } 
		 else {
			//Show wrong view warning. 
			var viewWarning = document.createElement("div");
			viewWarning.className = "simplemessage-error";
			viewWarning.innerHTML = "Not in Campus Itinerary view. Please switch views.<br><br>";
			warningBox.innerHTML ="";
			warningBox.appendChild(viewWarning);
			return;
		 }
}

//Close the dropdown menu if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.BereaBlue')) {

    var dropdowns = document.getElementsByClassName("BereaDropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
};

/*Creates the itineray and fills in the fields
I could reduce the lines of code to fill in the activity, location and detail, and then seperate times
but I kept them apart so that in the future if they need to be different they can*/
function creatBereaItinerary(x){
	//Look to see if they need an interview. 	
	var scheduleInterview = document.getElementById("text3791").value;
	
	if(x === 2 || x=== 1){
		
		//Visit Type
		document.getElementById('text598').value ="Weekday Morning Session";
		//Arrival Time
		document.getElementById('text3381').value ="8:45 a.m.";
		//activity 1 (Activity, time, location, detail)
		document.getElementById('text3321').value ="Arrive on Campus";
		document.getElementById('text3341').value ="8:45 a.m.";
		document.getElementById('text4581').value ="Haaga House";
		document.getElementById('text4541').value ="- Lobby";
		//activity 2
		document.getElementById('text4681').value ="Introduction to Berea";
		document.getElementById('text4627').value ="9:00 a.m.";
		document.getElementById('text4589').value ="Haaga House";
		document.getElementById('text4543').value ="- Presentation Room";
		//activity 3
		document.getElementById('text4683').value ="Information Session";
		document.getElementById('text4629').value ="9:10 a.m.";
		document.getElementById('text4591').value ="Haaga House";
		document.getElementById('text4545').value ="- Presentation Room";
		//activity 4
		//Look to see if scheduled interview is yes, otherwise we assume personal conversation
		if (scheduleInterview === "y"){
			document.getElementById('text4685').value ="Personal Interview";
		}
		else{
			document.getElementById('text4685').value ="Personal Conversation w/ Counselor";
		}
		document.getElementById('text4631').value ="9:45 a.m.";
		document.getElementById('text4593').value ="Haaga House";
		document.getElementById('text4547').value ="With Admissions Counselor";
		//activity 5
		document.getElementById('text4687').value ="Student Panel";
		document.getElementById('text4633').value ="10:05 a.m.";
		document.getElementById('text4595').value ="Haaga House";
		document.getElementById('text4549').value ="- Lobby";
		//activity 6
		document.getElementById('text4689').value ="Tour of Campus";
		document.getElementById('text4635').value ="10:30 a.m.";
		document.getElementById('text4597').value ="";
		document.getElementById('text4551').value ="With Student Ambassador";
		
		//For 1* visit, no lunch
		if(x === 1){
			//activity 7
			document.getElementById('text4691').value ="Depart from Campus";
			document.getElementById('text4637').value ="12:00 a.m.";
			document.getElementById('text4599').value ="";
			document.getElementById('text4553').value ="";
			//clear activity 8
			document.getElementById('text4693').value ="";
			document.getElementById('text4639').value ="";
			document.getElementById('text4601').value ="";
			document.getElementById('text4555').value ="";
		//For 4* visit with lunch
		} else if (x === 2){
			//Activity 7
			document.getElementById('text4691').value ="Lunch";
			document.getElementById('text4637').value ="12:00 a.m.";
			document.getElementById('text4599').value ="Dining Services";
			document.getElementById('text4553').value ="With Student Ambassador";
			//activity 8
			document.getElementById('text4693').value ="Depart from Campus";
			document.getElementById('text4639').value ="1:00 p.m.";
			document.getElementById('text4601').value ="";
			document.getElementById('text4555').value ="";
		}
	return false;
	} else if( x === 3) {
		//Visit Type
		document.getElementById('text598').value ="Weekday Afternoon Session";
		//Arrival Time
		document.getElementById('text3381').value ="1:15 p.m.";
		//activity 1 (Activity, time, location, detail)
		document.getElementById('text3321').value ="Arrive on Campus";
		document.getElementById('text3341').value ="1:15 p.m.";
		document.getElementById('text4581').value ="Haaga House";
		document.getElementById('text4541').value ="- Lobby";
		//activity 2
		document.getElementById('text4681').value ="Introduction to Berea";
		document.getElementById('text4627').value ="1:30 p.m.";
		document.getElementById('text4589').value ="Haaga House";
		document.getElementById('text4543').value ="- Presentation Room";
		//activity 3
		document.getElementById('text4683').value ="Information Session";
		document.getElementById('text4629').value ="1:40 p.m.";
		document.getElementById('text4591').value ="Haaga House";
		document.getElementById('text4545').value ="- Presentation Room";
		//activity 4
		//Look to see if scheduled interview is yes, otherwise we assume personal conversation
		if (scheduleInterview === "y"){
			document.getElementById('text4685').value ="Personal Interview";
		}
		else{
			document.getElementById('text4685').value ="Personal Conversation w/ Counselor";
		}
		document.getElementById('text4631').value ="2:15 p.m.";
		document.getElementById('text4593').value ="Haaga House";
		document.getElementById('text4547').value ="with Admissions Counselor";
		//activity 5
		document.getElementById('text4687').value ="Student Panel";
		document.getElementById('text4633').value ="2:35 p.m.";
		document.getElementById('text4595').value ="Haaga House";
		document.getElementById('text4549').value ="- Lobby";
		//activity 6
		document.getElementById('text4689').value ="Tour of Campus";
		document.getElementById('text4635').value ="3:00 p.m.";
		document.getElementById('text4597').value ="";
		document.getElementById('text4551').value ="With Student Ambassador";
		//activity 7
		document.getElementById('text4691').value ="Depart from Campus";
		document.getElementById('text4637').value ="4:30 p.m.";
		document.getElementById('text4599').value ="";
		document.getElementById('text4553').value ="";
		//clear activity 8
		document.getElementById('text4693').value ="";
		document.getElementById('text4639').value ="";
		document.getElementById('text4601').value ="";
		document.getElementById('text4555').value ="";
		
	} else if( x === 4) {
		
		//Visit Type
		document.getElementById('text598').value ="Weekday Midday Session";
		//Arrival Time
		document.getElementById('text3381').value ="10:15 a.m.";
		//activity 1 (Activity, time, location, detail)
		document.getElementById('text3321').value ="Arrive on Campus";
		document.getElementById('text3341').value ="10:15 a.m.";
		document.getElementById('text4581').value ="Haaga House";
		document.getElementById('text4541').value ="- Lobby";
		//activity 2
		document.getElementById('text4681').value ="Introduction to Berea";
		document.getElementById('text4627').value ="10:30 a.m.";
		document.getElementById('text4589').value ="Haaga House";
		document.getElementById('text4543').value ="- Presentation Room";
		//activity 3
		document.getElementById('text4683').value ="Information Session";
		document.getElementById('text4629').value ="10:40 a.m.";
		document.getElementById('text4591').value ="Haaga House";
		document.getElementById('text4545').value ="- Presentation Room";
		//activity 4
		//Look to see if scheduled interview is yes, otherwise we assume personal conversation
		if (scheduleInterview === "y"){
			document.getElementById('text4685').value ="Personal Interview";
		}
		else{
			document.getElementById('text4685').value ="Personal Conversation w/ Counselor";
		}
		document.getElementById('text4631').value ="11:15 a.m.";
		document.getElementById('text4547').value ="With Admissions Counselor";
		document.getElementById('text4593').value ="Haaga House";
		//activity 5
		document.getElementById('text4687').value ="Student Panel";
		document.getElementById('text4633').value ="11:35 a.m.";
		document.getElementById('text4595').value ="Haaga House";
		document.getElementById('text4549').value ="- Lobby";
		//activity 6
		document.getElementById('text4689').value ="Lunch";
		document.getElementById('text4635').value ="12:05 p.m.";
		document.getElementById('text4597').value ="Dining Services";
		document.getElementById('text4551').value ="With Student Ambassador";
		//activity 7
		document.getElementById('text4691').value ="Tour of Campus";
		document.getElementById('text4637').value ="12:45 p.m.";
		document.getElementById('text4599').value ="";
		document.getElementById('text4553').value ="";
		//activity 8
		document.getElementById('text4693').value ="Depart from Campus";
		document.getElementById('text4639').value ="1:45 p.m.";
		document.getElementById('text4601').value ="";
		document.getElementById('text4555').value ="";
	}
		//Clear activity 9 and 10 since we don't use it. 
		//activity 9
		document.getElementById('text4695').value ="";
		document.getElementById('text4641').value ="";
		document.getElementById('text4603').value ="";
		document.getElementById('text4557').value ="";
		//activity 10
		document.getElementById('text4697').value ="";
		document.getElementById('text4643').value ="";
		document.getElementById('text4605').value ="";
		document.getElementById('text4559').value ="";
}

//Clears all itinerary fields
function clearItinerary(){
	//Visit Type
		document.getElementById('text598').value ="";
		//Arrival Time
		document.getElementById('text3381').value ="";
		//activity 1 (Activity, time, location, detail)
		document.getElementById('text3321').value ="";
		document.getElementById('text3341').value ="";
		document.getElementById('text4581').value ="";
		document.getElementById('text4541').value ="";
		//activity 2
		document.getElementById('text4681').value ="";
		document.getElementById('text4627').value ="";
		document.getElementById('text4589').value ="";
		document.getElementById('text4543').value ="";
		//activity 3
		document.getElementById('text4683').value ="";
		document.getElementById('text4629').value ="";
		document.getElementById('text4591').value ="";
		document.getElementById('text4545').value ="";
		//activity 4
		document.getElementById('text4685').value ="";
		document.getElementById('text4631').value ="";
		document.getElementById('text4593').value ="";
		document.getElementById('text4547').value ="";
		//activity 5
		document.getElementById('text4687').value ="";
		document.getElementById('text4633').value ="";
		document.getElementById('text4595').value ="";
		document.getElementById('text4549').value ="";
		//activity 6
		document.getElementById('text4689').value ="";
		document.getElementById('text4635').value ="";
		document.getElementById('text4597').value ="";
		document.getElementById('text4551').value ="";
		//activity 7
		document.getElementById('text4691').value ="";
		document.getElementById('text4637').value ="";
		document.getElementById('text4599').value ="";
		document.getElementById('text4553').value ="";
		//clear activity 8
		document.getElementById('text4693').value ="";
		document.getElementById('text4639').value ="";
		document.getElementById('text4601').value ="";
		document.getElementById('text4555').value ="";
		//activity 9
		document.getElementById('text4695').value ="";
		document.getElementById('text4641').value ="";
		document.getElementById('text4603').value ="";
		document.getElementById('text4557').value ="";
		//activity 10
		document.getElementById('text4697').value ="";
		document.getElementById('text4643').value ="";
		document.getElementById('text4605').value ="";
		document.getElementById('text4559').value ="";
}
